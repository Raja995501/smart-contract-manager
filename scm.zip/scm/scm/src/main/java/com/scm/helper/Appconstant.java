package com.scm.helper;

public class Appconstant {
    public static final String name="scm";
    public static final String USER_ROLE="USER_ROLE";


}
